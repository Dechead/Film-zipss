﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using MySql.Data.MySqlClient;

namespace GibJohn_task
{
    public partial class Form2 : System.Windows.Forms.Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are You Sure To Exit Programme ?", "Exit", MessageBoxButtons.OKCancel) == DialogResult.OK)
            {
                Application.Exit();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (MessageBox.Show("Are You Sure you want to go back ?", "Back", MessageBoxButtons.OKCancel) == DialogResult.OK)
            {
                Form1 newform1 = new Form1();
                this.Hide();
                newform1.FormClosed += (s, args) =>
                this.Close();
                newform1.Show();
                newform1.Location = this.Location;
            }
        }

        private void passbox_s_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string username = userbox_S.Text;

            bool validUsername = validateUsernamePresence(username);

            string password = passbox_s.Text;

            bool validPassword = ValidatePassword(password);

            string Name = namebox_s.Text;

            bool validName = ValidateNamePrescence(Name);

            string Email = emailbox_s.Text;

            bool validEmail = ValidateEmail(Email);

            string confirmPassword = confirm_s.Text;

            bool validconfirm = ValidateConfirmPrescence(password, confirmPassword);


            if (validUsername && validPassword && validName && validEmail && validconfirm)
            {
                Form1 newform1 = new Form1();
                MessageBox.Show(
                    "You have successfully created an account",
                    "Account created",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Hide();
                newform1.FormClosed += (s, args) => this.Close();

                newform1.Show();
                newform1.Location = this.Location;
            }
            else if (validUsername)
            {
                passbox_s.Text = "";
                userbox_S.BackColor = Color.White;
            }
            else if (validPassword)
            {
                userbox_S.Text = "";
                passbox_s.BackColor = Color.White;
            }
            else if (validName)
            {
                namebox_s.Text = "";
                namebox_s.BackColor = Color.White;
            }
            else if (validEmail)
            {
                emailbox_s.Text = "";
                emailbox_s.BackColor = Color.White;
            }
            else if (validconfirm)
            {
                confirm_s.Text = "";
                emailbox_s.BackColor = Color.White;
            }

            bool passMatch = false;
            bool passwMatch = false;

            if (passbox_s.Text == confirm_s.Text)
            {
                passMatch = true;
            }

            string passw = passbox_s.Text;
            if (passw.Length > 6 && passw.Length < 25)
            {
                passwMatch = true;
            }

            if (passwMatch && passMatch)
            {
                InsertNewUser();
            }



        }

        private bool validateUsernamePresence(string input)
        {
            if (String.IsNullOrWhiteSpace(input))
            {
                userbox_S.BackColor = Color.FromArgb(0xFF, 0xFF, 0xCA, 0xCA);
                userbox_S.Focus();
                string message = "Username must not be empty!";
                string caption = "Error!";
                MessageBox.Show(message, caption, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return false;
            }
            return true;
        }
        private bool ValidateNamePrescence(string input)
        {
            if (String.IsNullOrWhiteSpace(input))
            {
                namebox_s.BackColor = Color.FromArgb(0xFF, 0xFF, 0xCA, 0xCA);
                namebox_s.Focus();
                string message = "Name feild must not be empty";
                string caption = "Error";
                MessageBox.Show(message, caption, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return false;
            }
            return true;
        }
        private bool ValidateEmail(string input)
        {
            var regex = new Regex("(?=.*\\.)(?!.*\\.{2})([\\w\\d.]){3,64}@[\\w\\d.]{3,255}");
            if (!regex.IsMatch(input))
            {
                emailbox_s.BackColor = Color.FromArgb(0xFF, 0xFF, 0xCA, 0xCA);
                emailbox_s.Focus();
                string message = "Must have local length between 3 and 64, Valid Email Required";
                string caption = "Error";
                MessageBox.Show(message, caption, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return false;
            }
            return true;
        }

        private bool ValidateConfirmPrescence(string password, string confirmPassword)
        {
            if (!password.Equals(confirmPassword))
            {
                confirm_s.BackColor = Color.FromArgb(0xFF, 0xFF, 0xCA, 0xCA);
                confirm_s.Focus();
                string message = "Passwords must match!";
                string caption = "Error";
                MessageBox.Show(message, caption, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return false;
            }
            return true;
        }

        private bool ValidatePassword(string input)
        {
            var regex = new Regex("(?=.*[a-z].*)(?=.*[A-Z].*)(?=.*\\d.*).{8,20}");

            if (!regex.IsMatch(input))
            {
                passbox_s.BackColor = Color.FromArgb(0xFF, 0xFF, 0xCA, 0xCA);
                passbox_s.Focus();
                string message = "Your password needs a Capital letter a number and a special character, Your password must also contain 8 or more letters";
                string caption = "Error!";
                MessageBox.Show(message, caption, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return false;
            }
            return true;

        }
        private void namebox_s_TextChanged(object sender, EventArgs e)
        {

        }

        private void userbox_s_TextChanged(object sender, EventArgs e)
        {

        }

        private void emailbox_s_TextChanged(object sender, EventArgs e)
        {

        }

        private void confirm_s_TextChanged(object sender, EventArgs e)
        {

        }
        private void peekPassword(object sender, EventArgs e)
        {
            this.passbox_s.PasswordChar = '\0';
            this.confirm_s.PasswordChar = '\0';
        }

        private void hidePassword(object sender, EventArgs e)
        {
            this.passbox_s.PasswordChar = '●';
            this.confirm_s.PasswordChar = '●';
        }
        public MySqlConnection ConnectToDB()
        {
            MySqlConnection conSQL = new MySqlConnection();

            conSQL.ConnectionString = @"server=localhost; uid=root; database=gibjohn";

            MessageBox.Show("Connection has been made successfully.");

            return conSQL;
        }
        
        private void InsertNewUser()
        {
            MySqlConnection insertSQL = ConnectToDB();

            string CommandText = "INSERT INTO user_details(Name, Username, Email, Password) " +
                "VALUES (@name, @username, @email, @passw);";

            using (insertSQL)
            {
                MySqlCommand insertDataCommand = new MySqlCommand(CommandText, insertSQL);

                insertDataCommand.Parameters.Add("@name", MySqlDbType.VarChar);
                insertDataCommand.Parameters["@name"].Value = namebox_s.Text;

                insertDataCommand.Parameters.Add("@username", MySqlDbType.VarChar);
                insertDataCommand.Parameters["@username"].Value = userbox_S.Text;


                insertDataCommand.Parameters.Add("@email", MySqlDbType.VarChar);
                insertDataCommand.Parameters["@email"].Value = emailbox_s.Text;

                insertDataCommand.Parameters.Add("@passw", MySqlDbType.VarChar);
                insertDataCommand.Parameters["@passw"].Value = passbox_s.Text;

                try       
                {
                    insertSQL.Open();

                    insertDataCommand.ExecuteReader();       

                    MessageBox.Show("Connection made. \nInserting New User Data...");       
                    insertSQL.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    if (insertSQL == null)
                    {
                        MessageBox.Show("Connection Failed!");
                    }
                }

            }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {

        }
    }
}
