﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace GibJohn_task
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public MySqlConnection ConnectToDB()
        {
            MySqlConnection conSQL = new MySqlConnection();
            
            conSQL.ConnectionString = @"server=localhost; uid=root; database=gibjohn";

            MessageBox.Show("Connection has been made successfully.");

            return conSQL;
        }


        private void Form1_Load(object sender, EventArgs e)
        {
           
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            bool match = FetchUserDetails();

            if (match)
            {
                Form3 newform3 = new Form3();
                this.Hide();
                newform3.FormClosed += (s, args) =>
                this.Close();
                newform3.Show();
                newform3.Location = this.Location;
            }
            else
            {
                MessageBox.Show("No match found, please try again.\nOr sign up for an account if you are new here.");
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form2 newform2 = new Form2();
            this.Hide();
            newform2.FormClosed += (s, args) =>
            this.Close();
            newform2.Show();
            newform2.Location = this.Location;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are You Sure To Exit Programme ?", "Exit", MessageBoxButtons.OKCancel) == DialogResult.OK)
            {
                Application.Exit();
            }
        }

        private void maskedTextBox2_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void maskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
        private bool FetchUserDetails()
        {
            bool matchFound = false;

            MySqlConnection bnb_Connect = ConnectToDB(); 

            MySqlDataReader myDataReader;  

            string CommandText = "SELECT Username, Email, Password FROM user_details WHERE Username=@username AND Password=@passw";

            using (bnb_Connect)
            {
                MySqlCommand findUser = new MySqlCommand(CommandText, bnb_Connect);

                findUser.Parameters.Add("@username", MySqlDbType.VarChar);
                findUser.Parameters["@username"].Value = userbox_L.Text;

                findUser.Parameters.Add("@passw", MySqlDbType.VarChar);
                findUser.Parameters["@passw"].Value = passbox_L.Text;

                try
                {
                    bnb_Connect.Open();
                    MessageBox.Show("Executing SQL.");
                    myDataReader = findUser.ExecuteReader();

                    MessageBox.Show("Finished SQL execution.");
                    if (myDataReader.Read())
                    {
                        matchFound = true;

                        string name = myDataReader.GetString(0); 
                        string email = myDataReader["Email"].ToString();
                        string pass = myDataReader.GetString(2);  

                        MessageBox.Show(string.Format("name: {0}\npass: {1}\nemail: {2}", name, pass, email));
                    }

                    myDataReader.Close();
                    bnb_Connect.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }

            return matchFound;
        }

        private void button2_Click_1(object sender, EventArgs e)
        {

        }
        private void peekPassword(object sender, EventArgs e)
        {
            this.passbox_L.PasswordChar = '\0';
        }

        private void hidePassword(object sender, EventArgs e)
        {
            this.passbox_L.PasswordChar = '●';
        }
    }
}
